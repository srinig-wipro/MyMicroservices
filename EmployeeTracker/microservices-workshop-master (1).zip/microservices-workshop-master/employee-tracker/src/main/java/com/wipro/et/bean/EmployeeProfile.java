package com.wipro.et.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class EmployeeProfile {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(unique=true, length=20)
	private String name;
	
	@OneToMany(mappedBy="employee", cascade=CascadeType.ALL)
	private List<EmployeeContactNumber> contactNumbers = new ArrayList<>();
	
	public EmployeeProfile() {}
	
	public EmployeeProfile(String name) {
		super();
		this.name = name;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	public List<EmployeeContactNumber> getContactNumbers() {
		return contactNumbers;
	}

	public void setContactNumbers(List<EmployeeContactNumber> contactNumbers) {
		this.contactNumbers = contactNumbers;
	}
	
	public void addContactNumbers(List<Integer> cellNumbers) {
		for(Integer cn: cellNumbers){
			EmployeeContactNumber ecn = new EmployeeContactNumber();
			ecn.setCellNumber(cn);
			ecn.setEmployeeId(this);
			contactNumbers.add(ecn);
		}
		
	}

	@Override
	public String toString() {
		return "Employee Id=" + id + ", Employee Name=" + name + ", contactNumbers=" + contactNumbers + "]";
	}
	
}
