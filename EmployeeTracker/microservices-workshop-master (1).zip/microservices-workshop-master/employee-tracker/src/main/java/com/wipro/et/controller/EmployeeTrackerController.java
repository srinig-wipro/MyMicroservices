package com.wipro.et.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.MultiValueMap;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.wipro.et.bean.EmployeeProfile;
import com.wipro.et.service.EmployeeTrackerService;

@Controller
public class EmployeeTrackerController {

	@Autowired
	EmployeeTrackerService employeeTrackerService;
	
    @PostMapping("/createEmployee")
    public String createEmployee(@RequestParam MultiValueMap<String, String> params, Model model) {
        
    	String empName = params.getFirst("name");
    	String contact1 = params.getFirst("contact1");
    	String contact2 = params.getFirst("contact2");
    	
        EmployeeProfile emp = new EmployeeProfile(empName);
        List<Integer> contacts = new ArrayList<>();
        contacts.add(Integer.parseInt(contact1));
        contacts.add(Integer.parseInt(contact2));
        emp.addContactNumbers(contacts);
        
        String status = employeeTrackerService.createEmployeeProfile(emp);
        model.addAttribute("status", "Status: "+status);
        
        return "genericResponse";
    }
    
    @GetMapping("/displayEmployees")
    public String displayEmployees(Model model) {
    	model.addAttribute("employees",employeeTrackerService.getEmployees());
    	return "displayEmployees";
    }
    
    @PostMapping("/searchEmployee")
    public String searchEmployee(@RequestParam MultiValueMap<String, String> params, Model model) {
    	String empName = params.getFirst("name");
    	String empId = params.getFirst("empId");
    	EmployeeProfile emp = null;
    	
    	if(empId != null && empId.length() > 0) {
    		emp = employeeTrackerService.getEmployeeProfileById(Integer.parseInt(empId));
    	}
    	
    	if(emp == null) {
			if(empName != null && empName.length() > 0) {
				emp = employeeTrackerService.getEmployeeProfileByName(empName);
			}
		}
    	
    	if(emp == null) {
    		model.addAttribute("status", "Status: Employee by Id: "+empId+"or Name: "+empName+" not found");
    		return "genericResponse";
    	}
    	model.addAttribute("employees",new EmployeeProfile[] {emp});
    	return "displayEmployees";
    }
    
    @ExceptionHandler({Exception.class})
    public ModelAndView handleError(Exception ex) {
    	ModelAndView mv = new ModelAndView();
    	mv.addObject("status", "Error occured: "+ex.getMessage());
    	mv.setViewName("genericResponse");
    	return mv;
    }

}