package com.wipro.et.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.et.bean.EmployeeContactNumber;
import com.wipro.et.bean.EmployeeProfile;
import com.wipro.et.dao.EmployeeRepository;

@Service
public class EmployeeTrackerServiceImpl implements EmployeeTrackerService {

	@Autowired
	private EmployeeRepository repository;

	@Override
	@Transactional
	public String createEmployeeProfile(EmployeeProfile emp) {
		EmployeeProfile newEmp;
		try {
			newEmp = repository.save(emp);
		} catch (Exception e) {
			return "Unable to create profile";
		}
		return "SUCCESS. Create EmployeId: "+newEmp.getId()+" for "+newEmp.getName();
	}

	@Override
	public EmployeeProfile getEmployeeProfileById(Integer id) {
		Optional<EmployeeProfile> emp = repository.findById(id);
		return emp.isPresent() ? emp.get() : null;
	}

	@Override
	public EmployeeProfile getEmployeeProfileByName(String name) {
		Optional<EmployeeProfile> emp = repository.findByNameIgnoreCase(name);
		return emp.isPresent() ? emp.get() : null;
	}

	@Override
	public List<Integer> getCellNumbers(Integer id) {
		List<Integer> cellNumbers = new ArrayList<>();
		Optional<EmployeeProfile> emp = repository.findById(id);
		if (emp.isPresent()) {
			for (EmployeeContactNumber cn : emp.get().getContactNumbers()) {
				cellNumbers.add(cn.getCellNumber());
			}

		}
		return cellNumbers.size() > 0 ? cellNumbers : null;
	}

	@Override
	public List<EmployeeProfile> getEmployees() {
		return repository.findAll();
	}

}
