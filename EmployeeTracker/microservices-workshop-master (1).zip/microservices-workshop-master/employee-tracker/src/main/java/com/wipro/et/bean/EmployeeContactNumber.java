package com.wipro.et.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class EmployeeContactNumber {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int id;
	
	@Column(unique=true)
	private int cellNumber;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name="employeeId")
	private EmployeeProfile employee;
	
	public EmployeeContactNumber() {
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public EmployeeProfile getEmployeeId() {
		return employee;
	}

	public void setEmployeeId(EmployeeProfile employeeId) {
		this.employee = employeeId;
	}

	public int getCellNumber() {
		return cellNumber;
	}

	public void setCellNumber(int cellNumber) {
		this.cellNumber = cellNumber;
	}

	@Override
	public String toString() {
		return cellNumber+"";
	}
	
}
