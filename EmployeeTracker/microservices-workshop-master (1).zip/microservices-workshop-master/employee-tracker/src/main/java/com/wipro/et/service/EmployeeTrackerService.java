package com.wipro.et.service;

import java.util.List;

import com.wipro.et.bean.EmployeeProfile;

public interface EmployeeTrackerService {
	String createEmployeeProfile(EmployeeProfile emp);
	EmployeeProfile getEmployeeProfileById(Integer id);
	EmployeeProfile getEmployeeProfileByName(String name);
	List<Integer> getCellNumbers(Integer id);
	List<EmployeeProfile> getEmployees();
}
