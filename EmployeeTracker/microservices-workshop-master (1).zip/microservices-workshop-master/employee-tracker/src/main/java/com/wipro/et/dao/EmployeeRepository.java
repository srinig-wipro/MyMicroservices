package com.wipro.et.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.wipro.et.bean.EmployeeProfile;

@Repository
public interface EmployeeRepository extends JpaRepository<EmployeeProfile, Integer> {
	Optional<EmployeeProfile> findByNameIgnoreCase(String name);

}
