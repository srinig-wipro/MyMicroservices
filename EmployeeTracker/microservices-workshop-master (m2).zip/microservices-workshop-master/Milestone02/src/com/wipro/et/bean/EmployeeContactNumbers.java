package com.wipro.et.bean;

public class EmployeeContactNumbers {
	int id, employeeid, number;

	public EmployeeContactNumbers(int id, int employeeid, int number) {
		
		this.id = id;
		this.employeeid = employeeid;
		this.number = number;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getEmployeeid() {
		return employeeid;
	}

	public void setEmployeeid(int employeeid) {
		this.employeeid = employeeid;
	}

	public int getNumber() {
		return number;
	}

	public void setNumber(int number) {
		this.number = number;
	}
	

}
