package com.wipro.et.dao;

public class EmployeeDao {

}
