package com.dao;

import java.util.List;
import java.util.stream.Stream;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.entity.Student;


/**
 * @author AVITEPA
 * Aug 22, 2018
 */
public interface StudentRepository extends CrudRepository<Student, Integer>{
	
	List<Student> findByName(@Param("name")String name);
	
    @Query("select c from Student c where c.name = :name")
    Stream<Student> findByNameStream(@Param("name") String name);
    
	
	@Modifying
    @Query("UPDATE Student s SET s.name = :name WHERE s.id = :id")
    int updateName(@Param("id") int id, @Param("name") String name);
	
//    @Query("FROM Student E WHERE E.name =:name")
//    Student findByNameOne(@Param("name")String name);

}
