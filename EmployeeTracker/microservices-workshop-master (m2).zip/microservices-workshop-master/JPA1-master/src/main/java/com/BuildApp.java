package com;

import java.util.List;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.transaction.annotation.Transactional;

import com.dao.StudentRepository;
import com.entity.Student;

/**
 * @author AVITEPA Aug 21, 2018
 */
@SpringBootApplication
public class BuildApp implements CommandLineRunner {

	private static final Logger log = LoggerFactory.getLogger(BuildApp.class);

	@Autowired
	StudentRepository repo;

//	@Autowired
//	DataSource datasource;

	public static void main(String[] args) {
		System.out.println(" #### Begins ###");
		SpringApplication.run(BuildApp.class, args);
		System.out.println("### End ###");
	}

	  @Transactional
	//@Transactional(readOnly = true)
	@Override
	public void run(String... args) throws Exception {

		//log.info("\n\n******** 1.save() *******");
		System.out.println("******** 1.save() *******");
		repo.save(new Student(1, "Avinash"));
		repo.save(new Student(2, "Patel"));
		repo.save(new Student(3, "Raj"));

		//log.info("\n\n******** 2.findAll().********");
		System.out.println("******** 2.findAll(). *******");
		for (Student student : repo.findAll()) {
			//log.info(student.toString());
			System.out.println(student.toString());
		}
		
		
		System.out.println("******** 3.findOne(). *******");
		System.out.println(repo.findOne(1));
		//repo.findOne(1).ifPresent(Student->{log.info(student.toString());});
		
		System.out.println("******** 4.findByxxx(). *******");
	      for (Student student : repo.findByName("Patel")) {
	          System.out.println(student);
	      }
		

	
	      System.out.println(repo.updateName(2, "WWW"));
		
		


		log.info("--------------------------------------------");
	}

}
