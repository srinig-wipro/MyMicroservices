package com.service;

import java.util.List;

import com.entity.Product;

public interface ProductService {
	
	public List<Product> getAllProduct();
	public Product getProductByID(int id);
	public String saveProduct(Product product);
	public void deleteProductByID(Product product);
	
	

}
