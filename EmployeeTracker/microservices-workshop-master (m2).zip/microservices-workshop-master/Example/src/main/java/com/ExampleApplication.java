package com;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.dao.ProductRepository;
import com.entity.Product;

@SpringBootApplication
public class ExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExampleApplication.class, args);
	}
	
	@Bean
	public CommandLineRunner setup(ProductRepository productRepository)
	{
		System.out.println("#############");
		return (args) -> {
			productRepository.save(new Product("A","aa"));
			productRepository.save(new Product("B","bb"));
			productRepository.save(new Product("C","cc"));
			productRepository.save(new Product("D","dd"));
		};
	}
}
