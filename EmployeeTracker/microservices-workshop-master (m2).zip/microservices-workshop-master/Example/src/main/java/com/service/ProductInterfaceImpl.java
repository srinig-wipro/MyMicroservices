package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.ProductRepository;
import com.entity.Product;

@Service("ProductService")
public class ProductInterfaceImpl implements ProductService{
	
	@Autowired
	ProductRepository productRepository;

	@Override
	public List<Product> getAllProduct() {
		// TODO Auto-generated method stub
		return productRepository.findAll();
	}

	@Override
	public Product getProductByID(int id) {
		// TODO Auto-generated method stub
		return productRepository.findOne(2);
	}

	@Override
	public String saveProduct(Product product) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteProductByID(Product product) {
		// TODO Auto-generated method stub
		productRepository.delete(product);
	}

	 
	

}
