/**
 * 
 */
package com.entity;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * @author MA260329
 *
 */
@Entity
@Table(name="JPA_Promotion")
public class Promotion implements Serializable{
	
	@Id
	long productId;

	String promotionType;
	
	String name;
	
	String fromDate;
	
	String toDate;
	
	
	
	/**
	 * 
	 */
	public Promotion() {
		super();
	}


	/**
	 * @param productId
	 * @param promotionId
	 * @param promotionValue
	 * @param discountPrice
	 */
	


	/**
	 * @return the productId
	 */
	public long getProductId() {
		return productId;
	}

	/**
	 * @param productId the productId to set
	 */
	public void setProductId(long productId) {
		this.productId = productId;
	}

	/**
	 * @return the promotionId
	 */
	
	public void setPromotionType(String promotionType) {
		this.promotionType = promotionType;
	}
	
	public String getPromotionType() {
		return promotionType;
	}

	/**
	 * @param promotionId the promotionId to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public String getFromDate() {
		return fromDate;
	}


	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}


	public String getToDate() {
		return toDate;
	}


	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	/**
	 * @return the promotionValue
	 */
	

	/**
	 * @param promotionValue the promotionValue to set
	 */
	
	/**
	 * @return the discountPrice
	 */
	
	/**
	 * @param discountPrice the discountPrice to set
	 */
	
	
	
	
}
