package com.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.entity.Promotion;
import com.repository.PromotionRepository;

@Service("PromotionService")
public class PromotionServiceImpl implements PromotionService{

	@Autowired
	PromotionRepository promotionRepository;
	
	@Override
	public Promotion getPromotion(long productId) {
		// TODO Auto-generated method stub
		return promotionRepository.findOne(productId);
	}

	@Override
	public Promotion addPromotion(Promotion promotion) {
		// TODO Auto-generated method stub
		return promotionRepository.save(promotion);
	}

	@Override
	public int updatePromotion(long productId, Promotion promotion) {
		// TODO Auto-generated method stub
		Promotion promo = promotionRepository.findOne(productId);
		if (promo.getProductId() == promotion.getProductId()) {
			System.out.println("inside if, product id matches to update promotion details");
			promo.setProductId(promotion.getProductId());
			promo.setPromotionType(promotion.getPromotionType());
			promo.setName(promotion.getName());
			promo.setFromDate(promotion.getFromDate());
			promo.setToDate(promotion.getToDate());
			promotionRepository.save(promo);
			return 1;
		} else {
			System.out.println("inside else, product id not matches to update promotion details");
			return 2;
		}
	}

	@Override
	public void deletePromotion(long productId) {
		// TODO Auto-generated method stub
		//if(productId == promotion.getProductId()) {
		promotionRepository.delete(productId);
		//}
	}

	@Override
	public List<Promotion> getAllPromotions() {
		// TODO Auto-generated method stub
		return promotionRepository.findAll();
	}

}
