/**
 * 
 */
package com.service;

import java.util.List;

import com.entity.Promotion;

/**
 * @author MA260329
 *
 */
public interface PromotionService {

	public List<Promotion> getAllPromotions();
	public Promotion getPromotion(long productId);
	public Promotion addPromotion(Promotion promotion);
	public int updatePromotion(long productId, Promotion promotion);
	public void deletePromotion(long productId);
}
