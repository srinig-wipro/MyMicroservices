package com.controller;
/**
 * 
 */


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Promotion;
import com.service.PromotionService;


@RestController
public class PromotionController {

	@Autowired
	PromotionService promotionservice;
	
	@RequestMapping("/promotions")
	public List<Promotion> getAllPromotions(){
		return promotionservice.getAllPromotions();
	}
	
	@RequestMapping("/promotions/{id}")
	public Promotion getPromotion(@PathVariable long id){
		return promotionservice.getPromotion(id);
	}
	
	@RequestMapping(method=RequestMethod.POST, value = "/promotions")
	public Promotion addPromotion(@RequestBody Promotion promotion) {
		return promotionservice.addPromotion(promotion);
	}
	
	@RequestMapping(method=RequestMethod.PUT, value = "/promotions/{id}")
	public void updatePromotion(@PathVariable long id, @RequestBody Promotion promotion) {
		promotionservice.updatePromotion(id, promotion);
	}
	

	@RequestMapping(method=RequestMethod.DELETE, value = "/promotions/{id}")
	public void deletePromotion(@PathVariable long id) {
		promotionservice.deletePromotion(id);
	}
}
