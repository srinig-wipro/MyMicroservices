package com.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.repository.query.Param;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.entity.Product;
import com.service.ProductService;

@RestController
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@RequestMapping(value="/product",method=RequestMethod.GET)
	public ResponseEntity<List<Product>> getAllProduct()	{
		
		return new ResponseEntity<List<Product>> (productService.getAllProducts(),HttpStatus.OK);
				
		
		
	}
	
	@RequestMapping(value="/product/{name}",method=RequestMethod.GET)
	public ResponseEntity<List<Product>> getAllProductByName(@PathVariable("name") String name)	{
		System.out.println("#### "+name);
		return new ResponseEntity<List<Product>> (productService.getProductByName(name),HttpStatus.OK);
				
		
		
	}

}
