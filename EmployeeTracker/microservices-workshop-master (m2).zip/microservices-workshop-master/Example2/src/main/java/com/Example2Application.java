package com;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.dao.ProductRepository;
import com.entity.Product;
import com.entity.ProductDescription;

@SpringBootApplication
public class Example2Application {

	public static void main(String[] args) {
		SpringApplication.run(Example2Application.class, args);
	}
	
	@Bean
	CommandLineRunner setup(ProductRepository repo)
	{
		return (args)->{
			repo.save(new Product("Cell Phone",new ProductDescription("6 inch","Gold","small")));
			repo.save(new Product("Cell Phone1",new ProductDescription("12 inch","Gold1","regular")));
			repo.save(new Product("Cell Phone2",new ProductDescription("18 inch","Gold2","small")));
			repo.save(new Product("CellPhone3",new ProductDescription("18 inch","Gold2","small")));
			
		};
	}
}
