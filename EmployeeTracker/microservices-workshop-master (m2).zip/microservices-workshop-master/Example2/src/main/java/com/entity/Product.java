package com.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product implements Serializable{
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	long id;
	

	@Column
	String name;
	
	@Embedded
	ProductDescription productDescription;

	
	public Product() {
		super();
	}
	
	



	public Product(String name, ProductDescription description) {
		super();
		this.name = name;
		this.productDescription = description;
	}



	public Product(long id, String name, ProductDescription description) {
		super();
		this.id = id;
		this.name = name;
		this.productDescription = description;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public ProductDescription getDescription() {
		return productDescription;
	}

	public void setDescription(ProductDescription description) {
		this.productDescription = description;
	}
	
	

}
