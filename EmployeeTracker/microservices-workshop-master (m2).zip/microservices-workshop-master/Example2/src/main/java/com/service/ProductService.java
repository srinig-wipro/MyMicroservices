package com.service;

import java.util.List;

import com.entity.Product;

public interface ProductService {
	
	public List<Product> getAllProducts();
	public Product getProductByID(int id);
	public List<Product> getProductByName(String name);
	public String saveProduct(Product product);
	public void deleteProduct(Product product);
	public int updateProductName();
	
	

}
