package com.CaseStudy.Service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.CaseStudy.Entity.Promotion;




@Service
public class PromotionService {
	
	private List<Promotion> promotions = new ArrayList<Promotion>();
	
	
	public List<Promotion> getAllPromotions() 
	{
		return promotions;
	}
	
	public Promotion getPromotion(String id) 
	{
		return promotions.stream().filter(p -> p.getProductID().equals(id)).findFirst().get();
	}
	
	public void addPromotion(Promotion promotion)
	{
		promotions.add(promotion);
	}
	
	public void updatePromotion(String id, Promotion promotion) 
	{
		for(int i=0;i<promotions.size();i++) 
		{
			Promotion p=promotions.get(i);
			if(p.getProductID().equals(id)) 
			{
				promotions.set(i, promotion);
				return;
			}
		}
	}
	
	public void deletePromotion(String id) {
		promotions.removeIf(p->p.getProductID().equals(id));
	}
}
