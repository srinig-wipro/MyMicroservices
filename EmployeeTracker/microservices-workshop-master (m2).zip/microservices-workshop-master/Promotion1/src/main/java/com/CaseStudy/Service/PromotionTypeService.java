package com.CaseStudy.Service;



import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;
import com.CaseStudy.Entity.PromotionType;




@Service
public class PromotionTypeService {
	
	private List<PromotionType> promotionTypes = new ArrayList<PromotionType>();
	
	public List<PromotionType> getAllPromotionTypes() 
	{
		return promotionTypes;
	}
	
	public PromotionType getPromotionType(String id) 
	{
		return promotionTypes.stream().filter(p -> p.getPromotionTypeID().equals(id)).findFirst().get();
	}
	public void addPromotionType(PromotionType promotionType)
	{
		promotionTypes.add(promotionType);
	}
	
	public void updatePromotionType(String id, PromotionType promotionType) 
	{
		for(int i=0;i<promotionTypes.size();i++) 
		{
			PromotionType p=promotionTypes.get(i);
			if(p.getPromotionTypeID().equals(id)) 
			{
				promotionTypes.set(i, promotionType);
				return;
			}
		}
	}
	
	public void deletePromotionType(String id) {
		promotionTypes.removeIf(p->p.getPromotionTypeID().equals(id));
	}
}
