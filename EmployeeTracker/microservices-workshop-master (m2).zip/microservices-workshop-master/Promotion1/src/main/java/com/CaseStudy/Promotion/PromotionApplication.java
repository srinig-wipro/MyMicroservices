package com.CaseStudy.Promotion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.CaseStudy.Controller")
@ComponentScan("com.CaseStudy.Entity")
@ComponentScan("com.CaseStudy.Service")
public class PromotionApplication {

	public static void main(String[] args) {
		SpringApplication.run(PromotionApplication.class, args);
	}
}
