package com.CaseStudy.Controller;

import java.util.List;

//import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.CaseStudy.Entity.Promotion;
import com.CaseStudy.Service.PromotionService;

@RestController
public class PromotionController {
	
	@Autowired
	private PromotionService promotionservice;
	
	
	
	@RequestMapping("/promotions")
	public List<Promotion> getAllPromotions()
	{
		return promotionservice.getAllPromotions();
		
	}
	
	@RequestMapping("/promotions/{id}")
	public Promotion getPromotion(@PathVariable String id) {
		return promotionservice.getPromotion(id);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/promotions")
	public void addPromotion(@RequestBody Promotion promotion) {
		promotionservice.addPromotion(promotion);
		
	}

	@RequestMapping(method=RequestMethod.PUT,value="/promotions/{id}")
	public void updatePromotion(@PathVariable String id, @RequestBody Promotion promotion)
	{
		promotionservice.updatePromotion(id, promotion);
	}

	@RequestMapping(method=RequestMethod.DELETE,value="/promotions/{id}")
	public void deletePromotion(@PathVariable String id)
	{
		promotionservice.deletePromotion(id);
	}
}

