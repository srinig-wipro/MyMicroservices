package com.wipro.et.service;

import java.util.List;

import com.wipro.et.bean.Employee;
import com.wipro.et.dao.EmployeeDao;

public class EmployeeTracker {
	
	public EmployeeTracker()
	{
		
	}
	
	public EmployeeTracker(List<Employee> employees)
	{
		EmployeeDao.setEmployees(employees);
	}
	
	public String createEmployeeProfile(Employee emp)
	{
		String name = emp.getName();
		EmployeeDao e = new EmployeeDao();
		
		int flag = 1;
		List<Employee> temp = EmployeeDao.getEmployees();
		
		for(int i=0;i<temp.size();i++)
		{
			if(name.equals(temp.get(i).getName()))
			{
				flag = 0;
				break;
			}
				
		}
		
		if(flag==1)
		{
			String str = e.saveEmployee(emp);
			return str;
		}
		
			return "Unable to create profile...seems already name exists";
	}
	
	public Employee getEmployeeById(int id)
	{
		List<Employee> temp = EmployeeDao.getEmployees();
		for(int i=0;i<temp.size();i++)
		{
			if(id == temp.get(i).getId())
			{
				return temp.get(i);
			}
				
		}
		return null;
	}
	
	public Employee getEmployeeByName(String name)
	{
		List<Employee> temp = EmployeeDao.getEmployees();
		for(int i=0;i<temp.size();i++)
		{
			if(name.equals(temp.get(i).getName()))
			{
				return temp.get(i);
			}
				
		}
		return null;
	}
	
	public List<Long> getEmployeeCellNumbers(int empid)
	{
		List<Employee> temp = EmployeeDao.getEmployees();
		for(int i=0;i<temp.size();i++)
		{
			if(empid == temp.get(i).getId())
			{
				return temp.get(i).getCellNumbers();
			}
				
		}
		return null;
	}
	
	public List<Employee> getEmployees()
	{
		return EmployeeDao.getEmployees();
	}

}
