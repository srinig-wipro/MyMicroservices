package com.CaseStudy.Entity;

public class PromotionType {
	String promotionTypeID;
	String type;
	public PromotionType() {
		super();
	}
	public PromotionType(String promotionTypeID, String type) {
		super();
		this.promotionTypeID = promotionTypeID;
		this.type = type;
	}
	public String getPromotionTypeID() {
		return promotionTypeID;
	}
	public void setPromotionTypeID(String promotionTypeID) {
		this.promotionTypeID = promotionTypeID;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	

}
