package com.CaseStudy.Entity;

public class Promotion {
	
	
	String productID,promotionTypeID;
	String name,from,to;
	public Promotion(String productID, String promotionTypeID, String name, String from, String to) {
		super();
		this.productID = productID;
		this.promotionTypeID = promotionTypeID;
		this.name = name;
		this.from = from;
		this.to = to;
	}
	public Promotion() {
		super();
	}
	public String getProductID() {
		return productID;
	}
	public void setProductID(String productID) {
		this.productID = productID;
	}
	public String getPromotionTypeID() {
		return promotionTypeID;
	}
	public void setPromotionTypeID(String promotionTypeID) {
		this.promotionTypeID = promotionTypeID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFrom() {
		return from;
	}
	public void setFrom(String from) {
		this.from = from;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}

	
}
