package com.CaseStudy.Controller;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.CaseStudy.Entity.PromotionType;
import com.CaseStudy.Service.PromotionTypeService;

@RestController
public class PromotionTypeController {
	
	@Autowired
	private PromotionTypeService promotionTypeservice;
	
	@RequestMapping("/promotionTypes")
	public List<PromotionType> getAllPromotionTypes()
	{
		return promotionTypeservice.getAllPromotionTypes();
		
	}
	
	@RequestMapping("/promotionTypes/{id}")
	public PromotionType getPromotionType(@PathVariable String id) {
		return promotionTypeservice.getPromotionType(id);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/promotionTypes")
	public void addPromotionType(@RequestBody PromotionType promotionType) {
		promotionTypeservice.addPromotionType(promotionType);
		
	}

	@RequestMapping(method=RequestMethod.PUT,value="/promotionTypes/{id}")
	public void updatePromotionType(@PathVariable String id, @RequestBody PromotionType promotionType)
	{
		promotionTypeservice.updatePromotionType(id, promotionType);
	}

	@RequestMapping(method=RequestMethod.DELETE,value="/promotionTypes/{id}")
	public void deletePromotionType(@PathVariable String id)
	{
		promotionTypeservice.deletePromotionType(id);
	}
}

